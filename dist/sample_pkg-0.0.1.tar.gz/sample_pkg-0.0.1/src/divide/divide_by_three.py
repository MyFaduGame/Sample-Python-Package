def divide_by_three(num):
	return num / 3